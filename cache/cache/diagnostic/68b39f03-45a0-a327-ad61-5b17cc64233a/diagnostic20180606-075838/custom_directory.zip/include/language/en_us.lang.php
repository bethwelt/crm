<?php
$GLOBALS['app_list_strings']['country_list']=array (
  'country' => 'Country',
);

$GLOBALS['app_list_strings']['countries_list']=array (
);
$GLOBALS['app_list_strings']['partner_list']=array (
);
$GLOBALS['app_list_strings']['partner_dom']=array (
);
$app_list_strings['moduleList']['cost_Costs']='Opportunity Costs';
$app_list_strings['moduleListSingular']['cost_Costs']='Opportunity Cost';
$app_list_strings['moduleList']['Sup_Supplier']='Suppliers';
$app_list_strings['moduleListSingular']['Sup_Supplier']='Supplier';
$GLOBALS['app_list_strings']['unit_list']=array (
  'PCS' => 'PCS',
);
$GLOBALS['app_list_strings']['invstatus_list']=array (
  'Onstock' => 'Onstock',
  'Sold' => 'Sold',
  'Delivered' => 'Delivered',
  'Pending' => 'Pending',
);
$GLOBALS['app_list_strings']['invconditions_list']=array (
  'New' => 'New',
  'Old' => 'Old',
);
$app_strings['LBL_GROUPTAB5_1527275204'] = 'New Group';

$GLOBALS['app_list_strings']['product_def_list']=array (
  'pcs' => 'pcs',
);
$app_list_strings['moduleListSingular']['INV_Inventories']='Inventory';
$app_list_strings['moduleList']['INV_Inventories']='Inventory';

$GLOBALS['app_list_strings']['type_list']=array (
  '' => '',
  'Service' => 'Service',
  'Product' => 'Product',
);