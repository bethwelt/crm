<?php
// created: 2018-06-05 16:56:09
$GLOBALS['tabStructure'] = array (
  'LBL_TABGROUP_SALES' => 
  array (
    'label' => 'LBL_TABGROUP_SALES',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Accounts',
      2 => 'Contacts',
      3 => 'Opportunities',
      4 => 'CO_Costs',
      5 => 'AOS_Products',
      6 => 'AOS_Product_Categories',
      7 => 'INV_Inventories',
      8 => 'AOS_Quotes',
      9 => 'AOS_Invoices',
    ),
  ),
  'LBL_TABGROUP_ACTIVITIES' => 
  array (
    'label' => 'LBL_TABGROUP_ACTIVITIES',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Calendar',
      2 => 'Calls',
      3 => 'Meetings',
      4 => 'Emails',
      5 => 'Tasks',
      6 => 'Notes',
    ),
  ),
);