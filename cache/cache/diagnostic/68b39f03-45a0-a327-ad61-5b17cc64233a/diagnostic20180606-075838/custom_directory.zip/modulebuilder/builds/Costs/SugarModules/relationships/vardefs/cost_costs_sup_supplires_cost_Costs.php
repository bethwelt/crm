<?php
// created: 2018-05-22 14:49:54
$dictionary["cost_Costs"]["fields"]["cost_costs_sup_supplires"] = array (
  'name' => 'cost_costs_sup_supplires',
  'type' => 'link',
  'relationship' => 'cost_costs_sup_supplires',
  'source' => 'non-db',
  'module' => 'sup_Supplires',
  'bean_name' => 'sup_Supplires',
  'vname' => 'LBL_COST_COSTS_SUP_SUPPLIRES_FROM_SUP_SUPPLIRES_TITLE',
);
