<?php
// created: 2018-05-22 14:49:54
$dictionary["sup_Supplires"]["fields"]["cost_costs_sup_supplires"] = array (
  'name' => 'cost_costs_sup_supplires',
  'type' => 'link',
  'relationship' => 'cost_costs_sup_supplires',
  'source' => 'non-db',
  'module' => 'cost_Costs',
  'bean_name' => 'cost_Costs',
  'vname' => 'LBL_COST_COSTS_SUP_SUPPLIRES_FROM_COST_COSTS_TITLE',
);
