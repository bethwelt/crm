<?php
// created: 2018-05-22 14:49:54
$dictionary["partn_Partners"]["fields"]["cost_costs_partn_partners"] = array (
  'name' => 'cost_costs_partn_partners',
  'type' => 'link',
  'relationship' => 'cost_costs_partn_partners',
  'source' => 'non-db',
  'module' => 'cost_Costs',
  'bean_name' => 'cost_Costs',
  'vname' => 'LBL_COST_COSTS_PARTN_PARTNERS_FROM_COST_COSTS_TITLE',
);
