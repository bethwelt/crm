<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-05-16 23:21:38
$dictionary['Opportunity']['fields']['client_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['client_c']['labelValue']='Client';

 

 // created: 2018-05-16 23:04:16
$dictionary['Opportunity']['fields']['country_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['country_c']['labelValue']='Country';

 

 // created: 2018-05-16 23:04:59
$dictionary['Opportunity']['fields']['gmamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmamount_c']['labelValue']='Gross Margin Amount';

 

 // created: 2018-05-16 23:07:08
$dictionary['Opportunity']['fields']['gmperc_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmperc_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['gmperc_c']['labelValue']='Gross Margin percentage';
$dictionary['Opportunity']['fields']['gmperc_c']['enable_range_search']='1';

 

 // created: 2018-06-05 12:23:44
$dictionary['Opportunity']['fields']['negamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['negamount_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['negamount_c']['labelValue']='Negotiation Amount';
$dictionary['Opportunity']['fields']['negamount_c']['enable_range_search']='1';

 

 // created: 2018-05-19 15:10:40
$dictionary['Opportunity']['fields']['deleted']['inline_edit']=true;
$dictionary['Opportunity']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Opportunity']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['deleted']['reportable']=true;

 

 // created: 2018-05-28 04:48:17
$dictionary['Opportunity']['fields']['account_id1_c']['inline_edit']=1;

 

 // created: 2018-05-28 04:48:17
$dictionary['Opportunity']['fields']['client_name_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['client_name_c']['labelValue']='Client';

 

 // created: 2018-06-05 12:36:12
$dictionary['Opportunity']['fields']['account_id2_c']['inline_edit']=1;

 

 // created: 2018-06-05 12:36:12
$dictionary['Opportunity']['fields']['clientname_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['clientname_c']['labelValue']='Client';

 

 // created: 2018-06-05 12:37:11
$dictionary['Opportunity']['fields']['lead_id_c']['inline_edit']=1;

 

 // created: 2018-06-05 12:37:11
$dictionary['Opportunity']['fields']['lead_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['lead_c']['labelValue']='Lead Source';

 

 // created: 2018-06-05 12:46:49
$dictionary['Opportunity']['fields']['type_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['type_c']['labelValue']='Type';

 

 // created: 2018-06-05 12:55:58
$dictionary['Opportunity']['fields']['contact_id_c']['inline_edit']=1;

 

 // created: 2018-06-05 12:55:58
$dictionary['Opportunity']['fields']['salesperson_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['salesperson_c']['labelValue']='Sales Person';

 

 // created: 2018-06-05 13:11:37
$dictionary['Opportunity']['fields']['datenext_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['datenext_c']['labelValue']='Date Next';

 

 // created: 2018-06-05 16:29:22
$dictionary['Opportunity']['fields']['co_costs_id_c']['inline_edit']=1;

 

 // created: 2018-06-05 16:29:22
$dictionary['Opportunity']['fields']['approachfees_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['approachfees_c']['labelValue']='Approach Fees';

 

 // created: 2018-06-05 16:30:53
$dictionary['Opportunity']['fields']['co_costs_id1_c']['inline_edit']=1;

 

 // created: 2018-06-05 16:30:53
$dictionary['Opportunity']['fields']['partnercost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['partnercost_c']['labelValue']='Partner Cost';

 
?>