<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_BT_PERSONS_1_FROM_BT_PERSONS_TITLE'] = 'Sales Persons';

?>