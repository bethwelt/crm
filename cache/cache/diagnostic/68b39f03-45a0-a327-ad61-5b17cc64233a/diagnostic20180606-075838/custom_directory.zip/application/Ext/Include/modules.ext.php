<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['cat_Categories'] = 'cat_Categories';
$beanFiles['cat_Categories'] = 'modules/cat_Categories/cat_Categories.php';
$moduleList[] = 'cat_Categories';


 
 //WARNING: The contents of this file are auto-generated
$beanList['CU_Customs'] = 'CU_Customs';
$beanFiles['CU_Customs'] = 'modules/CU_Customs/CU_Customs.php';
$moduleList[] = 'CU_Customs';


 
 //WARNING: The contents of this file are auto-generated
$beanList['CO_Costs'] = 'CO_Costs';
$beanFiles['CO_Costs'] = 'modules/CO_Costs/CO_Costs.php';
$moduleList[] = 'CO_Costs';


 
 //WARNING: The contents of this file are auto-generated
$beanList['Bt_Bank'] = 'Bt_Bank';
$beanFiles['Bt_Bank'] = 'modules/Bt_Bank/Bt_Bank.php';
$moduleList[] = 'Bt_Bank';


 
 //WARNING: The contents of this file are auto-generated
$beanList['INV_Inventories'] = 'INV_Inventories';
$beanFiles['INV_Inventories'] = 'modules/INV_Inventories/INV_Inventories.php';
$moduleList[] = 'INV_Inventories';


?>