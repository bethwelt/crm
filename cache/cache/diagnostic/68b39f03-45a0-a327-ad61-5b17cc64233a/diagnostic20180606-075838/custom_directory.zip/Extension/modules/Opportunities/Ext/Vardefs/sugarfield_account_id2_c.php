<?php
 // created: 2018-06-05 12:36:12
$dictionary['Opportunity']['fields']['account_id2_c']['inline_edit']=1;

 ?>