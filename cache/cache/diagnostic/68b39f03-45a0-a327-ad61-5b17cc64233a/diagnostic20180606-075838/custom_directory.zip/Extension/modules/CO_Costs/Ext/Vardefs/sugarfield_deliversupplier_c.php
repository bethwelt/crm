<?php
 // created: 2018-06-05 15:39:16
$dictionary['CO_Costs']['fields']['deliversupplier_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['deliversupplier_c']['labelValue']='Delivery &Package Supplier';

 ?>