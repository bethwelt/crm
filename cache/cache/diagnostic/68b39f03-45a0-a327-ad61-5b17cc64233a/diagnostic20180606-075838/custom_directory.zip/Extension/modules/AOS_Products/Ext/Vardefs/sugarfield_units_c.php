<?php
 // created: 2018-05-28 03:28:40
$dictionary['AOS_Products']['fields']['units_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['units_c']['labelValue']='Units';

 ?>