<?php
 // created: 2018-06-05 15:49:33
$dictionary['CO_Costs']['fields']['customcost_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['customcost_c']['labelValue']='Custom Cost';

 ?>