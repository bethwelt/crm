<?php
 // created: 2018-06-05 15:44:43
$dictionary['CO_Costs']['fields']['financialsupplier_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['financialsupplier_c']['labelValue']='Financial Supplier';

 ?>