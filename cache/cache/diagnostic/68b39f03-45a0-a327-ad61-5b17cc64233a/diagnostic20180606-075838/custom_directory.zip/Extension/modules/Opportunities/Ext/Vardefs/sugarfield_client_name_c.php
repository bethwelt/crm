<?php
 // created: 2018-05-28 04:48:17
$dictionary['Opportunity']['fields']['client_name_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['client_name_c']['labelValue']='Client';

 ?>