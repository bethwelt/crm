<?php
 // created: 2018-06-05 12:37:11
$dictionary['Opportunity']['fields']['lead_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['lead_c']['labelValue']='Lead Source';

 ?>