<?php
 // created: 2018-06-05 16:29:22
$dictionary['Opportunity']['fields']['co_costs_id_c']['inline_edit']=1;

 ?>