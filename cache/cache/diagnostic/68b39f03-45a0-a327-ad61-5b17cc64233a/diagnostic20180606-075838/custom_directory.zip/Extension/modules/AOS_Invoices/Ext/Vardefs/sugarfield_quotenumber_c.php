<?php
 // created: 2018-05-28 05:52:45
$dictionary['AOS_Invoices']['fields']['quotenumber_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['quotenumber_c']['labelValue']='Quote Number';

 ?>