<?php
 // created: 2018-06-05 15:36:06
$dictionary['CO_Costs']['fields']['partnername_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['partnername_c']['labelValue']='Partner Name';

 ?>