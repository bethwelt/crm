<?php
 // created: 2018-05-16 23:21:38
$dictionary['Opportunity']['fields']['client_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['client_c']['labelValue']='Client';

 ?>