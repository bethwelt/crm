<?php
 // created: 2018-06-05 12:23:44
$dictionary['Opportunity']['fields']['negamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['negamount_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['negamount_c']['labelValue']='Negotiation Amount';
$dictionary['Opportunity']['fields']['negamount_c']['enable_range_search']='1';

 ?>