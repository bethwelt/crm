<?php
 // created: 2018-06-05 15:40:52
$dictionary['CO_Costs']['fields']['freightsupplier_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['freightsupplier_c']['labelValue']='Freight Supplier';

 ?>