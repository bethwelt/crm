<?php
 // created: 2018-05-28 05:52:45
$dictionary['AOS_Invoices']['fields']['aos_quotes_id_c']['inline_edit']=1;

 ?>