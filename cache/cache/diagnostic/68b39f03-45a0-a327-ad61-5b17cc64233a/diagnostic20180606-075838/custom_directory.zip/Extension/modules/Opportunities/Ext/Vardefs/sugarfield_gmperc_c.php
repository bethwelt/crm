<?php
 // created: 2018-05-16 23:07:08
$dictionary['Opportunity']['fields']['gmperc_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmperc_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['gmperc_c']['labelValue']='Gross Margin percentage';
$dictionary['Opportunity']['fields']['gmperc_c']['enable_range_search']='1';

 ?>