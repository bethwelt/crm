<?php
 // created: 2018-06-05 15:46:52
$dictionary['CO_Costs']['fields']['transitcost_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['transitcost_c']['labelValue']='Transit Cost';

 ?>