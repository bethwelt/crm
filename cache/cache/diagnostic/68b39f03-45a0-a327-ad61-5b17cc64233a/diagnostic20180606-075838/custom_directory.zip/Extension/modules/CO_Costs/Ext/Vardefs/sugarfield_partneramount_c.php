<?php
 // created: 2018-06-05 15:51:44
$dictionary['CO_Costs']['fields']['partneramount_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['partneramount_c']['labelValue']='Partner Amount';

 ?>