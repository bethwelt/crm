<?php
 // created: 2018-06-05 15:53:02
$dictionary['CO_Costs']['fields']['country_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['country_c']['labelValue']='Country';

 ?>