<?php
 // created: 2018-06-05 16:30:53
$dictionary['Opportunity']['fields']['partnercost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['partnercost_c']['labelValue']='Partner Cost';

 ?>