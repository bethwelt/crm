<?php
 // created: 2018-06-05 12:55:58
$dictionary['Opportunity']['fields']['contact_id_c']['inline_edit']=1;

 ?>