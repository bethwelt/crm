<?php
 // created: 2018-05-28 03:20:00
$dictionary['AOS_Products']['fields']['qty_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['qty_c']['labelValue']='Quantity';

 ?>