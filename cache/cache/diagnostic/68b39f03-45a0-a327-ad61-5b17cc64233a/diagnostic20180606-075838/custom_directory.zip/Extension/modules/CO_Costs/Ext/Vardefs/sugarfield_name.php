<?php
 // created: 2018-06-05 17:46:41
$dictionary['CO_Costs']['fields']['name']['required']=true;
$dictionary['CO_Costs']['fields']['name']['inline_edit']=true;
$dictionary['CO_Costs']['fields']['name']['comments']='Name of the Sale';
$dictionary['CO_Costs']['fields']['name']['merge_filter']='disabled';
$dictionary['CO_Costs']['fields']['name']['unified_search']=false;

 ?>