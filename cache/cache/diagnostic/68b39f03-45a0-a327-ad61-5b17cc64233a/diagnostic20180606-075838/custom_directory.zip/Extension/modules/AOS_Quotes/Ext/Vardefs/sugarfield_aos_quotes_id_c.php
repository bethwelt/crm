<?php
 // created: 2018-05-28 05:45:23
$dictionary['AOS_Quotes']['fields']['aos_quotes_id_c']['inline_edit']=1;

 ?>