<?php
 // created: 2018-06-05 15:35:22
$dictionary['CO_Costs']['fields']['account_id_c']['inline_edit']=1;

 ?>