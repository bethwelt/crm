<?php
 // created: 2018-05-28 05:45:23
$dictionary['AOS_Quotes']['fields']['quotenumber_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['quotenumber_c']['labelValue']='Quote Number';

 ?>