<?php
 // created: 2018-06-05 15:34:50
$dictionary['CO_Costs']['fields']['opportunity_id_c']['inline_edit']=1;

 ?>