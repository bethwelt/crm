<?php
 // created: 2018-06-05 12:55:58
$dictionary['Opportunity']['fields']['salesperson_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['salesperson_c']['labelValue']='Sales Person';

 ?>