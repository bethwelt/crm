<?php
 // created: 2018-06-05 15:41:53
$dictionary['CO_Costs']['fields']['account_id4_c']['inline_edit']=1;

 ?>