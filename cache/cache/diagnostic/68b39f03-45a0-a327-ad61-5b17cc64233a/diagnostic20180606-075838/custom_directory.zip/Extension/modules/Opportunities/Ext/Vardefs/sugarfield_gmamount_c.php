<?php
 // created: 2018-05-16 23:04:59
$dictionary['Opportunity']['fields']['gmamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmamount_c']['labelValue']='Gross Margin Amount';

 ?>