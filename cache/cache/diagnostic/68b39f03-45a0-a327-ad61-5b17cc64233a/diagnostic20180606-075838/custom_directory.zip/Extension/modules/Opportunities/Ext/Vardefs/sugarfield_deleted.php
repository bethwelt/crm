<?php
 // created: 2018-05-19 15:10:40
$dictionary['Opportunity']['fields']['deleted']['inline_edit']=true;
$dictionary['Opportunity']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Opportunity']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['deleted']['reportable']=true;

 ?>