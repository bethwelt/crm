<?php
 // created: 2018-06-05 12:46:49
$dictionary['Opportunity']['fields']['type_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['type_c']['labelValue']='Type';

 ?>