<?php
 // created: 2018-04-20 10:18:47
$dictionary['Contact']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>