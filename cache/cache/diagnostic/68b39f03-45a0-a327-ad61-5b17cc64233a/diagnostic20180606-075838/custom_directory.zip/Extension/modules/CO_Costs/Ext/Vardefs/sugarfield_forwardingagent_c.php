<?php
 // created: 2018-06-05 15:41:53
$dictionary['CO_Costs']['fields']['forwardingagent_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['forwardingagent_c']['labelValue']='Forwarding Agent';

 ?>