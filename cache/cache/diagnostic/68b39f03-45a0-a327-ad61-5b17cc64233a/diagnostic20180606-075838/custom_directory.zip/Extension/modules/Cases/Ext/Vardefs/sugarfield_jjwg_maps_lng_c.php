<?php
 // created: 2018-04-20 10:18:43
$dictionary['Case']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>