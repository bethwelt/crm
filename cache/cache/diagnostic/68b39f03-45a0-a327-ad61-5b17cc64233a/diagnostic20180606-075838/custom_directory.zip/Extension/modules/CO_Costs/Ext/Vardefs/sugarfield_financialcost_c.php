<?php
 // created: 2018-06-05 15:45:34
$dictionary['CO_Costs']['fields']['financialcost_c']['inline_edit']='1';
$dictionary['CO_Costs']['fields']['financialcost_c']['labelValue']='Financial Cost';

 ?>