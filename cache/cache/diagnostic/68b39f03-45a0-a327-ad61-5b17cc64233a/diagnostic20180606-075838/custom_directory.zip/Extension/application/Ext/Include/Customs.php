<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['CU_Customs'] = 'CU_Customs';
$beanFiles['CU_Customs'] = 'modules/CU_Customs/CU_Customs.php';
$moduleList[] = 'CU_Customs';

?>