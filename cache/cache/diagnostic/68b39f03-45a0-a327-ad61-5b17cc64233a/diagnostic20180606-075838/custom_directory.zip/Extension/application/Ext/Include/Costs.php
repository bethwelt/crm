<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['CO_Costs'] = 'CO_Costs';
$beanFiles['CO_Costs'] = 'modules/CO_Costs/CO_Costs.php';
$moduleList[] = 'CO_Costs';

?>