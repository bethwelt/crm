<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['Bt_Bank'] = 'Bt_Bank';
$beanFiles['Bt_Bank'] = 'modules/Bt_Bank/Bt_Bank.php';
$moduleList[] = 'Bt_Bank';

?>