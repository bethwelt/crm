<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['INV_Inventories'] = 'INV_Inventories';
$beanFiles['INV_Inventories'] = 'modules/INV_Inventories/INV_Inventories.php';
$moduleList[] = 'INV_Inventories';

?>