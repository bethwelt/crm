<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['cat_Categories'] = 'cat_Categories';
$beanFiles['cat_Categories'] = 'modules/cat_Categories/cat_Categories.php';
$moduleList[] = 'cat_Categories';

?>