<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['cost_Costs'] = 'cost_Costs';
$beanFiles['cost_Costs'] = 'modules/cost_Costs/cost_Costs.php';
$moduleList[] = 'cost_Costs';

?>