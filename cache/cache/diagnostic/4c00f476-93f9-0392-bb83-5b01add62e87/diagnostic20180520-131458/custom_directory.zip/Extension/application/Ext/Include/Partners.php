<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['partn_Partners'] = 'partn_Partners';
$beanFiles['partn_Partners'] = 'modules/partn_Partners/partn_Partners.php';
$moduleList[] = 'partn_Partners';

?>