<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['Cu_Customers'] = 'Cu_Customers';
$beanFiles['Cu_Customers'] = 'modules/Cu_Customers/Cu_Customers.php';
$moduleList[] = 'Cu_Customers';

?>