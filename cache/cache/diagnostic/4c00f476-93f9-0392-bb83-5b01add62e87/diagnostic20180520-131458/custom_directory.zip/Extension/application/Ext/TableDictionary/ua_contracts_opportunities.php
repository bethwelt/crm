<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ua_contracts_opportunitiesMetaData.php');

?>