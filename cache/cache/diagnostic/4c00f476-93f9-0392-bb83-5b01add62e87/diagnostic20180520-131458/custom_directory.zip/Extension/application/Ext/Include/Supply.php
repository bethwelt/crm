<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['sup_Supplires'] = 'sup_Supplires';
$beanFiles['sup_Supplires'] = 'modules/sup_Supplires/sup_Supplires.php';
$moduleList[] = 'sup_Supplires';

?>