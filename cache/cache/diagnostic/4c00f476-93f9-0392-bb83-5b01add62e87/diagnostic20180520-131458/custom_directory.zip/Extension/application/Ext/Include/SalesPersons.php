<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['Bt_Persons'] = 'Bt_Persons';
$beanFiles['Bt_Persons'] = 'modules/Bt_Persons/Bt_Persons.php';
$moduleList[] = 'Bt_Persons';

?>