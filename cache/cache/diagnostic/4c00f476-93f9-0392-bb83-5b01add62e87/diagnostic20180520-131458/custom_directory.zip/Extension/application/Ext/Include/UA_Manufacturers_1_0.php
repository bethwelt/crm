<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['UA_Manufacturers'] = 'UA_Manufacturers';
$beanFiles['UA_Manufacturers'] = 'modules/UA_Manufacturers/UA_Manufacturers.php';
$moduleList[] = 'UA_Manufacturers';

?>