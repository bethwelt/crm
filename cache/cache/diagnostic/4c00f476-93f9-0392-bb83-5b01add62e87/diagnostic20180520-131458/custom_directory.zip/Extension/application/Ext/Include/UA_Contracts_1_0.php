<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['UA_Contracts'] = 'UA_Contracts';
$beanFiles['UA_Contracts'] = 'modules/UA_Contracts/UA_Contracts.php';
$moduleList[] = 'UA_Contracts';

?>