<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['INV_Invoices'] = 'INV_Invoices';
$beanFiles['INV_Invoices'] = 'modules/INV_Invoices/INV_Invoices.php';
$moduleList[] = 'INV_Invoices';

?>