<?php
 // created: 2018-05-17 14:42:17
$dictionary['cost_Costs']['fields']['pamount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pamount_c']['labelValue']='pamount';

 ?>