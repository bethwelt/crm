<?php
 // created: 2018-04-20 10:18:46
$dictionary['Contact']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>