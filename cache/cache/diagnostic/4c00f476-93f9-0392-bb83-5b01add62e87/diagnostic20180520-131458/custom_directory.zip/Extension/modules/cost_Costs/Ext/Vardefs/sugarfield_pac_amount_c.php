<?php
 // created: 2018-05-17 14:50:26
$dictionary['cost_Costs']['fields']['pac_amount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pac_amount_c']['labelValue']='pac amount';

 ?>