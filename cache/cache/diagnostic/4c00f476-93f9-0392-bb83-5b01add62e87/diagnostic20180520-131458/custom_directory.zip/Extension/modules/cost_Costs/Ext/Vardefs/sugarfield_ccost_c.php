<?php
 // created: 2018-05-17 14:53:10
$dictionary['cost_Costs']['fields']['ccost_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['ccost_c']['labelValue']='ccost';

 ?>