<?php
 // created: 2018-05-17 14:54:18
$dictionary['cost_Costs']['fields']['sup_supplires_id2_c']['inline_edit']=1;

 ?>