<?php
 // created: 2018-04-20 10:18:50
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>