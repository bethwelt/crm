<?php
 // created: 2018-05-17 15:47:40
$dictionary['cost_Costs']['fields']['country_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['country_c']['labelValue']='country';

 ?>