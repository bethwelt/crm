<?php
 // created: 2018-05-17 20:12:44
$dictionary['Opportunity']['fields']['bt_persons_id_c']['inline_edit']=1;

 ?>