<?php
 // created: 2018-05-17 14:33:41
$dictionary['cost_Costs']['fields']['partn_partners_id_c']['inline_edit']=1;

 ?>