<?php
 // created: 2018-05-17 20:24:22
$dictionary['Opportunity']['fields']['cost_costs_id1_c']['inline_edit']=1;

 ?>