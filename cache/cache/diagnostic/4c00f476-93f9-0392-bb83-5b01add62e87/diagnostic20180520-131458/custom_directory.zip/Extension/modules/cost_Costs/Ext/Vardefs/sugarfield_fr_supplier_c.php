<?php
 // created: 2018-05-17 14:51:42
$dictionary['cost_Costs']['fields']['fr_supplier_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['fr_supplier_c']['labelValue']='Fr supplier';

 ?>