<?php
 // created: 2018-05-17 20:24:22
$dictionary['Opportunity']['fields']['apfee_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['apfee_c']['labelValue']='apfee';

 ?>