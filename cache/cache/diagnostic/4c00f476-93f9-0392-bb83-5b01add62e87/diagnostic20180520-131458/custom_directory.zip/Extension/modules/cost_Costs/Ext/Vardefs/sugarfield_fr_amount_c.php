<?php
 // created: 2018-05-17 14:52:30
$dictionary['cost_Costs']['fields']['fr_amount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['fr_amount_c']['labelValue']='fr amount';

 ?>