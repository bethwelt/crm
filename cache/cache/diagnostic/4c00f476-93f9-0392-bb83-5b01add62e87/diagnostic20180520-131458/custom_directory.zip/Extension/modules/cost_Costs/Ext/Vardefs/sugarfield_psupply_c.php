<?php
 // created: 2018-05-17 14:48:43
$dictionary['cost_Costs']['fields']['psupply_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['psupply_c']['labelValue']='psupply';

 ?>