<?php
 // created: 2018-05-17 15:03:55
$dictionary['cost_Costs']['fields']['f_supplier_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['f_supplier_c']['labelValue']='f supplier';

 ?>