<?php
 // created: 2018-04-20 10:18:42
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>