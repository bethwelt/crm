<?php
 // created: 2018-05-17 15:56:45
$dictionary['Opportunity']['fields']['cost_costs_id_c']['inline_edit']=1;

 ?>