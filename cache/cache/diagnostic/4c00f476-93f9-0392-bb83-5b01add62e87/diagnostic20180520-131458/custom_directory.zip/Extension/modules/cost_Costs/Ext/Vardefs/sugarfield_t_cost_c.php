<?php
 // created: 2018-05-17 14:55:53
$dictionary['cost_Costs']['fields']['t_cost_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['t_cost_c']['labelValue']='t cost';

 ?>