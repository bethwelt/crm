<?php
 // created: 2018-05-17 15:03:55
$dictionary['cost_Costs']['fields']['bt_bank_id_c']['inline_edit']=1;

 ?>