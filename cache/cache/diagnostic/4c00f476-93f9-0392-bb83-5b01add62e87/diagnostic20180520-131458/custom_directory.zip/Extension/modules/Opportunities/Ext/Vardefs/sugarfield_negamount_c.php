<?php
 // created: 2018-05-16 23:06:10
$dictionary['Opportunity']['fields']['negamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['negamount_c']['labelValue']='Négociation Amount';

 ?>