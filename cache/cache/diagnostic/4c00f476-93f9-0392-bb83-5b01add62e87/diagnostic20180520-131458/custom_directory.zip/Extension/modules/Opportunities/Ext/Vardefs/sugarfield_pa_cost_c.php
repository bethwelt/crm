<?php
 // created: 2018-05-17 15:56:45
$dictionary['Opportunity']['fields']['pa_cost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['pa_cost_c']['labelValue']='pa cost';

 ?>