<?php
 // created: 2018-05-17 14:54:18
$dictionary['cost_Costs']['fields']['f_agent_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['f_agent_c']['labelValue']='f agent';

 ?>