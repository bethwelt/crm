<?php
 // created: 2018-05-17 14:33:41
$dictionary['cost_Costs']['fields']['pname_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pname_c']['labelValue']='pname';

 ?>