<?php
 // created: 2018-04-20 10:18:47
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>