<?php
 // created: 2018-05-17 09:57:00
$dictionary['cost_Costs']['fields']['cclient_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['cclient_c']['labelValue']='cclient';

 ?>