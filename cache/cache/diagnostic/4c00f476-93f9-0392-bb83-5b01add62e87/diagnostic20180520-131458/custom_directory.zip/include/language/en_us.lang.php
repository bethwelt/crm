<?php
$GLOBALS['app_list_strings']['country_list']=array (
  'country' => 'Country',
);

$GLOBALS['app_list_strings']['countries_list']=array (
);
$GLOBALS['app_list_strings']['partner_list']=array (
);
$GLOBALS['app_list_strings']['partner_dom']=array (
);