<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['Bt_Bank'] = 'Bt_Bank';
$beanFiles['Bt_Bank'] = 'modules/Bt_Bank/Bt_Bank.php';
$moduleList[] = 'Bt_Bank';


 
 //WARNING: The contents of this file are auto-generated
$beanList['cost_Costs'] = 'cost_Costs';
$beanFiles['cost_Costs'] = 'modules/cost_Costs/cost_Costs.php';
$moduleList[] = 'cost_Costs';


 
 //WARNING: The contents of this file are auto-generated
$beanList['Cu_Customers'] = 'Cu_Customers';
$beanFiles['Cu_Customers'] = 'modules/Cu_Customers/Cu_Customers.php';
$moduleList[] = 'Cu_Customers';


 
 //WARNING: The contents of this file are auto-generated
$beanList['INV_Invoices'] = 'INV_Invoices';
$beanFiles['INV_Invoices'] = 'modules/INV_Invoices/INV_Invoices.php';
$moduleList[] = 'INV_Invoices';


 
 //WARNING: The contents of this file are auto-generated
$beanList['partn_Partners'] = 'partn_Partners';
$beanFiles['partn_Partners'] = 'modules/partn_Partners/partn_Partners.php';
$moduleList[] = 'partn_Partners';


 
 //WARNING: The contents of this file are auto-generated
$beanList['Bt_Persons'] = 'Bt_Persons';
$beanFiles['Bt_Persons'] = 'modules/Bt_Persons/Bt_Persons.php';
$moduleList[] = 'Bt_Persons';


 
 //WARNING: The contents of this file are auto-generated
$beanList['sup_Supplires'] = 'sup_Supplires';
$beanFiles['sup_Supplires'] = 'modules/sup_Supplires/sup_Supplires.php';
$moduleList[] = 'sup_Supplires';


 
 //WARNING: The contents of this file are auto-generated
$beanList['UA_Manufacturers'] = 'UA_Manufacturers';
$beanFiles['UA_Manufacturers'] = 'modules/UA_Manufacturers/UA_Manufacturers.php';
$moduleList[] = 'UA_Manufacturers';


 
 //WARNING: The contents of this file are auto-generated
$beanList['UA_Contracts'] = 'UA_Contracts';
$beanFiles['UA_Contracts'] = 'modules/UA_Contracts/UA_Contracts.php';
$moduleList[] = 'UA_Contracts';


?>