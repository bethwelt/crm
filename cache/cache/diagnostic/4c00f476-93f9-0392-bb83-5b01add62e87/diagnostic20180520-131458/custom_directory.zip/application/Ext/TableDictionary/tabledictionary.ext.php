<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/cost_costs_sup_supplires_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ua_contracts_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ua_contracts_productsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ua_contracts_quotesMetaData.php');


?>