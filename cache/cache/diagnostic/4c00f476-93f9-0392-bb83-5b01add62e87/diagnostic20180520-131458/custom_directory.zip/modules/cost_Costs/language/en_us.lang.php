<?php
// created: 2018-05-17 15:49:10
$mod_strings = array (
  'LBL_OPPORTUMITY' => 'opportumity',
  'LBL_CCLIENT' => 'Client ',
  'LBL_PNAME_PARTN_PARTNERS_ID' => 'pname (related  ID)',
  'LBL_PNAME' => 'pname',
  'LBL_PAMOUNT' => 'Partner amount ',
  'LBL_PSUPPLY_SUP_SUPPLIRES_ID' => 'psupply (related  ID)',
  'LBL_PSUPPLY' => 'Delivery and packaging supplier',
  'LBL_PAC_AMOUNT' => 'Delivery and packaging amount',
  'LBL_FR_SUPPLIER_SUP_SUPPLIRES_ID' => 'Fr supplier (related  ID)',
  'LBL_FR_SUPPLIER' => 'Freight supplier ',
  'LBL_FR_AMOUNT' => 'Freight amount',
  'LBL_CCOST' => 'Custom cost',
  'LBL_F_AGENT_SUP_SUPPLIRES_ID' => 'Forwarding agent ',
  'LBL_F_AGENT' => 'Forwarding agent',
  'LBL_T_COST' => 'Transit cost',
  'LBL_F_COST' => 'Financial cost',
  'LBL_F_SUPPLIER_BT_BANK_ID' => 'f supplier (related  ID)',
  'LBL_F_SUPPLIER' => 'Financial supplier',
  'LBL_NAME' => 'Opportunity',
  'LBL_COUNTRY' => 'Country',
);