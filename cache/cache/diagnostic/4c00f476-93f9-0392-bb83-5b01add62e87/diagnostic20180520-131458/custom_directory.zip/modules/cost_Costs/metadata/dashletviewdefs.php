<?php
$dashletData['cost_CostsDashlet']['searchFields'] = array (
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'type' => 'assigned_user_name',
    'default' => 'Administrator',
  ),
);
$dashletData['cost_CostsDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'cclient_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_CCLIENT',
    'width' => '10%',
    'name' => 'cclient_c',
  ),
  'searchfields' => 
  array (
    'date_entered' => 
    array (
      'default' => '',
    ),
    'date_modified' => 
    array (
      'default' => '',
    ),
    'assigned_user_id' => 
    array (
      'type' => 'assigned_user_name',
      'default' => 'Administrator',
    ),
    'width' => '10%',
    'default' => true,
    'name' => 'searchfields',
  ),
  'currency_symbol' => 
  array (
    'type' => 'relate',
    'label' => 'LBL_CURRENCY_SYMBOL',
    'id' => 'CURRENCY_ID',
    'link' => true,
    'width' => '10%',
    'default' => true,
    'name' => 'currency_symbol',
  ),
  'date_closed' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_CLOSED',
    'width' => '10%',
    'default' => false,
    'name' => 'date_closed',
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
