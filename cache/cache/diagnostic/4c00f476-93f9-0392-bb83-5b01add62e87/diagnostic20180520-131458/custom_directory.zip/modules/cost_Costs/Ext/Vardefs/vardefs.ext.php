<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2018-05-17 14:24:56
$dictionary["cost_Costs"]["fields"]["cost_costs_sup_supplires_1"] = array (
  'name' => 'cost_costs_sup_supplires_1',
  'type' => 'link',
  'relationship' => 'cost_costs_sup_supplires_1',
  'source' => 'non-db',
  'module' => 'sup_Supplires',
  'bean_name' => 'sup_Supplires',
  'vname' => 'LBL_COST_COSTS_SUP_SUPPLIRES_1_FROM_SUP_SUPPLIRES_TITLE',
);


 // created: 2018-05-17 15:03:55
$dictionary['cost_Costs']['fields']['bt_bank_id_c']['inline_edit']=1;

 

 // created: 2018-05-17 09:57:00
$dictionary['cost_Costs']['fields']['cclient_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['cclient_c']['labelValue']='cclient';

 

 // created: 2018-05-17 14:53:10
$dictionary['cost_Costs']['fields']['ccost_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['ccost_c']['labelValue']='ccost';

 

 // created: 2018-05-17 15:47:40
$dictionary['cost_Costs']['fields']['country_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['country_c']['labelValue']='country';

 

 // created: 2018-05-17 14:52:30
$dictionary['cost_Costs']['fields']['fr_amount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['fr_amount_c']['labelValue']='fr amount';

 

 // created: 2018-05-17 14:51:42
$dictionary['cost_Costs']['fields']['fr_supplier_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['fr_supplier_c']['labelValue']='Fr supplier';

 

 // created: 2018-05-17 14:54:18
$dictionary['cost_Costs']['fields']['f_agent_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['f_agent_c']['labelValue']='f agent';

 

 // created: 2018-05-17 14:56:39
$dictionary['cost_Costs']['fields']['f_cost_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['f_cost_c']['labelValue']='f cost';

 

 // created: 2018-05-17 15:03:55
$dictionary['cost_Costs']['fields']['f_supplier_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['f_supplier_c']['labelValue']='f supplier';

 

 // created: 2018-05-17 14:50:26
$dictionary['cost_Costs']['fields']['pac_amount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pac_amount_c']['labelValue']='pac amount';

 

 // created: 2018-05-17 14:42:17
$dictionary['cost_Costs']['fields']['pamount_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pamount_c']['labelValue']='pamount';

 

 // created: 2018-05-17 14:33:41
$dictionary['cost_Costs']['fields']['partn_partners_id_c']['inline_edit']=1;

 

 // created: 2018-05-17 14:33:41
$dictionary['cost_Costs']['fields']['pname_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['pname_c']['labelValue']='pname';

 

 // created: 2018-05-17 14:48:43
$dictionary['cost_Costs']['fields']['psupply_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['psupply_c']['labelValue']='psupply';

 

 // created: 2018-05-17 14:51:42
$dictionary['cost_Costs']['fields']['sup_supplires_id1_c']['inline_edit']=1;

 

 // created: 2018-05-17 14:54:18
$dictionary['cost_Costs']['fields']['sup_supplires_id2_c']['inline_edit']=1;

 

 // created: 2018-05-17 14:48:43
$dictionary['cost_Costs']['fields']['sup_supplires_id_c']['inline_edit']=1;

 

 // created: 2018-05-17 14:55:53
$dictionary['cost_Costs']['fields']['t_cost_c']['inline_edit']='1';
$dictionary['cost_Costs']['fields']['t_cost_c']['labelValue']='t cost';

 
?>