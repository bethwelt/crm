<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_COST_COSTS_SUP_SUPPLIRES_1_FROM_SUP_SUPPLIRES_TITLE'] = 'Suppliers';

?>