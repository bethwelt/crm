<?php
// created: 2018-05-19 15:10:40
$mod_strings = array (
  'LBL_NEGAMOUNT' => 'Negotiation Amount',
  'LBL_GMAMOUNT' => 'Gross Margin Amount',
  'LBL_GMPERC' => 'Gross Margin percentage',
  'LBL_CLIENT' => 'Client',
  'LBL_COUNTRY' => 'Country',
  'LBL_PA_COST_COST_COSTS_ID' => 'pa cost (related  ID)',
  'LBL_PA_COST' => 'Partner cost',
  'LBL_S_PERSON_BT_PERSONS_ID' => 's person (related  ID)',
  'LBL_S_PERSON' => 'Sales Person',
  'LBL_APFEE_COST_COSTS_ID' => 'apfee (related  ID)',
  'LBL_APFEE' => 'Approach fees: ',
  'LBL_DELETED' => 'Deleted',
);