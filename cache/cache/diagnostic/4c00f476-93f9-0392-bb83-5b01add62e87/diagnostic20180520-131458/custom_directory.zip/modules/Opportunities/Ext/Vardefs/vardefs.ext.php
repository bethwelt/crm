<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-05-17 20:24:22
$dictionary['Opportunity']['fields']['apfee_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['apfee_c']['labelValue']='apfee';

 

 // created: 2018-05-17 20:12:44
$dictionary['Opportunity']['fields']['bt_persons_id_c']['inline_edit']=1;

 

 // created: 2018-05-16 23:21:38
$dictionary['Opportunity']['fields']['client_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['client_c']['labelValue']='Client';

 

 // created: 2018-05-17 20:24:22
$dictionary['Opportunity']['fields']['cost_costs_id1_c']['inline_edit']=1;

 

 // created: 2018-05-17 15:56:45
$dictionary['Opportunity']['fields']['cost_costs_id_c']['inline_edit']=1;

 

 // created: 2018-05-16 23:04:16
$dictionary['Opportunity']['fields']['country_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['country_c']['labelValue']='Country';

 

 // created: 2018-05-16 23:04:59
$dictionary['Opportunity']['fields']['gmamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmamount_c']['labelValue']='Gross Margin Amount';

 

 // created: 2018-05-16 23:07:08
$dictionary['Opportunity']['fields']['gmperc_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['gmperc_c']['options']='numeric_range_search_dom';
$dictionary['Opportunity']['fields']['gmperc_c']['labelValue']='Gross Margin percentage';
$dictionary['Opportunity']['fields']['gmperc_c']['enable_range_search']='1';

 

 // created: 2018-04-20 10:18:50
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2018-05-16 23:06:10
$dictionary['Opportunity']['fields']['negamount_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['negamount_c']['labelValue']='Négociation Amount';

 

 // created: 2018-05-17 15:56:45
$dictionary['Opportunity']['fields']['pa_cost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['pa_cost_c']['labelValue']='pa cost';

 

 // created: 2018-05-17 20:12:44
$dictionary['Opportunity']['fields']['s_person_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['s_person_c']['labelValue']='s person';

 

 // created: 2018-05-19 15:10:40
$dictionary['Opportunity']['fields']['deleted']['inline_edit']=true;
$dictionary['Opportunity']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Opportunity']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['deleted']['reportable']=true;

 
?>