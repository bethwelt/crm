<?php
$viewdefs ['Opportunities'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'currency_id',
            'comment' => 'Currency used for display purposes',
            'label' => 'LBL_CURRENCY',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'client_c',
            'label' => 'LBL_CLIENT',
          ),
          1 => 
          array (
            'name' => 'country_c',
            'studio' => 'visible',
            'label' => 'LBL_COUNTRY',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'amount',
            'label' => '{$MOD.LBL_AMOUNT} ({$CURRENCY})',
          ),
          1 => 'opportunity_type',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'gmamount_c',
            'label' => 'LBL_GMAMOUNT',
          ),
          1 => 'next_step',
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'gmperc_c',
            'label' => 'LBL_GMPERC',
          ),
          1 => 
          array (
            'name' => 'negamount_c',
            'label' => 'LBL_NEGAMOUNT',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 's_person_c',
            'studio' => 'visible',
            'label' => 'LBL_S_PERSON',
          ),
          1 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
        ),
        6 => 
        array (
          0 => 'date_closed',
          1 => 'account_name',
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'apfee_c',
            'studio' => 'visible',
            'label' => 'LBL_APFEE',
          ),
          1 => '',
        ),
        8 => 
        array (
          0 => 'sales_stage',
          1 => '',
        ),
        9 => 
        array (
          0 => 'probability',
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'pa_cost_c',
            'studio' => 'visible',
            'label' => 'LBL_PA_COST',
          ),
        ),
        11 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'nl2br' => true,
          ),
        ),
      ),
    ),
  ),
);
?>
