<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2018-04-20 10:18:44
$dictionary['Case']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2018-04-20 10:18:44
$dictionary['Case']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2018-04-20 10:18:43
$dictionary['Case']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2018-04-20 10:18:43
$dictionary['Case']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 
?>