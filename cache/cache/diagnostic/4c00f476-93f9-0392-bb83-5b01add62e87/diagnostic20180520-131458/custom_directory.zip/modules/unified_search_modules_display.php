<?php
// created: 2018-05-17 13:14:59
$unified_search_modules_display = array (
  'Accounts' => 
  array (
    'visible' => true,
  ),
  'Calls' => 
  array (
    'visible' => true,
  ),
  'Cases' => 
  array (
    'visible' => true,
  ),
  'Contacts' => 
  array (
    'visible' => true,
  ),
  'Documents' => 
  array (
    'visible' => true,
  ),
  'Leads' => 
  array (
    'visible' => true,
  ),
  'Meetings' => 
  array (
    'visible' => true,
  ),
  'Cu_Customers' => 
  array (
    'visible' => true,
  ),
  'Notes' => 
  array (
    'visible' => true,
  ),
  'sup_Supplires' => 
  array (
    'visible' => true,
  ),
  'partn_Partners' => 
  array (
    'visible' => true,
  ),
  'cost_Costs' => 
  array (
    'visible' => true,
  ),
  'Opportunities' => 
  array (
    'visible' => true,
  ),
  'AOBH_BusinessHours' => 
  array (
    'visible' => false,
  ),
  'AOD_Index' => 
  array (
    'visible' => false,
  ),
  'AOD_IndexEvent' => 
  array (
    'visible' => false,
  ),
  'AOK_Knowledge_Base_Categories' => 
  array (
    'visible' => false,
  ),
  'AOP_Case_Events' => 
  array (
    'visible' => false,
  ),
  'AOP_Case_Updates' => 
  array (
    'visible' => false,
  ),
  'AOR_Reports' => 
  array (
    'visible' => false,
  ),
  'AOR_Scheduled_Reports' => 
  array (
    'visible' => false,
  ),
  'AOS_Contracts' => 
  array (
    'visible' => false,
  ),
  'AOS_Invoices' => 
  array (
    'visible' => false,
  ),
  'AOS_PDF_Templates' => 
  array (
    'visible' => false,
  ),
  'AOS_Product_Categories' => 
  array (
    'visible' => false,
  ),
  'AOS_Products' => 
  array (
    'visible' => false,
  ),
  'AOS_Quotes' => 
  array (
    'visible' => false,
  ),
  'AOW_Processed' => 
  array (
    'visible' => false,
  ),
  'AOW_WorkFlow' => 
  array (
    'visible' => false,
  ),
  'Bugs' => 
  array (
    'visible' => false,
  ),
  'Calls_Reschedule' => 
  array (
    'visible' => false,
  ),
  'Campaigns' => 
  array (
    'visible' => false,
  ),
  'FP_Event_Locations' => 
  array (
    'visible' => false,
  ),
  'FP_events' => 
  array (
    'visible' => false,
  ),
  'INV_Invoices' => 
  array (
    'visible' => false,
  ),
  'OutboundEmailAccounts' => 
  array (
    'visible' => false,
  ),
  'Project' => 
  array (
    'visible' => false,
  ),
  'ProjectTask' => 
  array (
    'visible' => false,
  ),
  'ProspectLists' => 
  array (
    'visible' => false,
  ),
  'Prospects' => 
  array (
    'visible' => false,
  ),
  'Tasks' => 
  array (
    'visible' => false,
  ),
  'jjwg_Address_Cache' => 
  array (
    'visible' => false,
  ),
  'jjwg_Areas' => 
  array (
    'visible' => false,
  ),
  'jjwg_Maps' => 
  array (
    'visible' => false,
  ),
  'jjwg_Markers' => 
  array (
    'visible' => false,
  ),
);