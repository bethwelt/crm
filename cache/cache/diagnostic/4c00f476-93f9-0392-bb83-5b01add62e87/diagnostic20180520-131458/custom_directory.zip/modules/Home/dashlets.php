<?php 
$defaultDashlets =array (
  'MessageDashlet' => 'Home',
  'MyCallsDashlet' => 'Calls',
  'MyMeetingsDashlet' => 'Meetings',
  'MyOpportunitiesDashlet' => 'Opportunities',
  'MyAccountsDashlet' => 'Accounts',
  'MyLeadsDashlet' => 'Leads',
);