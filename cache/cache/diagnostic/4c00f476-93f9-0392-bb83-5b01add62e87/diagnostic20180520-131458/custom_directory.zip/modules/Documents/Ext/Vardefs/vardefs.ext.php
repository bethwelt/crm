<?php 
 //WARNING: The contents of this file are auto-generated



$dictionary['Document']['fields']['ua_contracts'] = array(
	'name' => 'contracts',
	'type' => 'link',
	'relationship' => 'ua_contracts_documents',
	'source' => 'non-db',
	'vname' => 'LBL_CONTRACTS',
);
?>