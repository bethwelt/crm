<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2018-05-17 14:24:56
$dictionary["sup_Supplires"]["fields"]["cost_costs_sup_supplires_1"] = array (
  'name' => 'cost_costs_sup_supplires_1',
  'type' => 'link',
  'relationship' => 'cost_costs_sup_supplires_1',
  'source' => 'non-db',
  'module' => 'cost_Costs',
  'bean_name' => 'cost_Costs',
  'vname' => 'LBL_COST_COSTS_SUP_SUPPLIRES_1_FROM_COST_COSTS_TITLE',
);

?>