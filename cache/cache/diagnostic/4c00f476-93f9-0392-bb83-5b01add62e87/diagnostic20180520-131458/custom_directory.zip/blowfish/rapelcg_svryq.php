<?php
// created: 2018-04-20 10:48:28
$key = array (
  0 => '9b9ce068-2970-cacc-551c-5ad9a9e377f8',
);