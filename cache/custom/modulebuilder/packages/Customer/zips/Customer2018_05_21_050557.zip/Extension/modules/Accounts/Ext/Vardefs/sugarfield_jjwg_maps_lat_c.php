<?php
 // created: 2018-04-20 10:18:41
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>