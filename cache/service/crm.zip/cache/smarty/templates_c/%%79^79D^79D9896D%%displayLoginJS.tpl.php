<?php /* Smarty version 2.6.29, created on 2018-05-29 01:08:24
         compiled from include/MVC/View/tpls/displayLoginJS.tpl */ ?>
<?php if ($this->_tpl_vars['MODULE_SUGAR_GRP1']): ?>
    <script type="text/javascript">var module_sugar_grp1 = '<?php echo $this->_tpl_vars['MODULE_SUGAR_GRP1']; ?>
';</script>
<?php endif; ?>
<?php if ($this->_tpl_vars['ACTION_SUGAR_GRP1']): ?>
    <script type="text/javascript">var action_sugar_grp1 = '<?php echo $this->_tpl_vars['ACTION_SUGAR_GRP1']; ?>
';</script>
<?php endif; ?>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['SUGAR_GRP1_JQUERY']; ?>
" z></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['SUGAR_GRP1_YUI']; ?>
"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['SUGAR_GRP1']; ?>
"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['CALENDAR']; ?>
"></script>
<script type="text/javascript">
<?php echo '
    if ( typeof(SUGAR) == \'undefined\' ) {SUGAR = {}};
    if ( typeof(SUGAR.themes) == \'undefined\' ) SUGAR.themes = {};
'; ?>

</script>

<?php if ($this->_tpl_vars['HEADERSYNC']): ?>
    <script type="text/javascript" src="<?php echo $this->_tpl_vars['HEADERSYNC']; ?>
"></script>
<?php endif; ?>