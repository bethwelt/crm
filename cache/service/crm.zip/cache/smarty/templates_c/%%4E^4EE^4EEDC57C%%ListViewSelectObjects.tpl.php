<?php /* Smarty version 2.6.29, created on 2018-05-28 06:16:39
         compiled from include/ListView/ListViewSelectObjects.tpl */ ?>
<span style='<?php echo $this->_tpl_vars['DISPLAY_STYLE']; ?>
' id='selectedRecordsTop'>
    <?php echo $this->_tpl_vars['APP']['LBL_LISTVIEW_SELECTED_OBJECTS']; ?>

    <input style='border: 0px; background: transparent; font-size: inherit; color: inherit' type='text' id='selectCountTop' type='text' id='selectCountTop' readonly name='selectCount[]' value='<?php echo $this->_tpl_vars['TOTAL_ITEMS_SELECTED']; ?>
' />
</span>