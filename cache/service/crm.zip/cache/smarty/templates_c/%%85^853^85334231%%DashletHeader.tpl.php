<?php /* Smarty version 2.6.29, created on 2018-05-29 01:08:50
         compiled from include/Dashlets/DashletHeader.tpl */ ?>
<?php echo $this->_tpl_vars['HEADER']; ?>