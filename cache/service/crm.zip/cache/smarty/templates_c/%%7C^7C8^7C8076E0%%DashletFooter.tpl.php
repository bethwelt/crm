<?php /* Smarty version 2.6.29, created on 2018-05-29 01:08:50
         compiled from include/Dashlets/DashletFooter.tpl */ ?>
</div><div class="mr"></div></div><div class="ft"><div class="bl"></div><div class="ft-center"></div><div class="br"></div></div>