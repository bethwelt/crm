Who are We?

We are a software engineer team.
We have experienced CRM systems (SugarCRM, vTigerCRM), Ad server systems (OpenX).
We contribute value to your organization by helping you reduce your time, resources, and cost of operating CRM and Ad server.
We create the best products so that your business will grow faster.

What We do?

We're an efficient, engineering-driven team making valuable products. We spend time to study your business and keep finding out methods to improve your software. We offer a wide range of CRM (SugarCRM, vTigerCRM) Modules, Plugins, Addons including integration with the most popular Accounting Software, Shop Carts and Content Management Systems, etc.
 
Install Contracts module for SugarCRM

After extract the .7z file, you will see a folder include .zip file installation ([UA_Contracts.zip).
You use Module Loader in SugarCRM to install package.