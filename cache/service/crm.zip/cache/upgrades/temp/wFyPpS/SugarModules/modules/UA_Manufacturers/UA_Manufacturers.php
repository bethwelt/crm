<?PHP

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/UA_Manufacturers/UA_Manufacturers_sugar.php');

class UA_Manufacturers extends UA_Manufacturers_sugar
{

    public function UA_Manufacturers()
    {
        parent::UA_Manufacturers_sugar();
    }

}