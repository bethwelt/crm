<?php
// created: 2018-05-21 03:10:11
$upgrade_config = array (
  1 => 
  array (
    'upgrade_vars' => 
    array (
    ),
  ),
  2 => 
  array (
    'upload' => 'in_progress',
  ),
);