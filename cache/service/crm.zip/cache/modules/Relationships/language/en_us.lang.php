<?php
// created: 2018-05-29 03:38:57
$mod_strings = array (
  'LBL_ID' => 'Relationship Id',
  'LBL_RELATIONSHIP_NAME' => 'Relationship Name',
  'LBL_LHS_MODULE' => 'LHS Module Name',
  'LBL_LHS_TABLE' => 'LHS Table Name',
  'LBL_LHS_KEY' => 'LHS Key Name',
  'LBL_RHS_MODULE' => 'RHS Module Name',
  'LBL_RHS_TABLE' => 'RHS Table Name',
  'LBL_RHS_KEY' => 'RHS Key Name',
  'LBL_JOIN_TABLE' => 'Join Table Name',
  'LBL_JOIN_KEY_LHS' => 'Join Key LHS',
  'LBL_JOIN_KEY_RHS' => 'Join Key RHS',
  'LBL_RELATIONSHIP_TYPE' => 'Relationship Type',
  'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Relationship Role Column Name',
  'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Relationship Role Column Value',
  'LBL_REVERSE' => 'Reverse',
  'LBL_DELETED' => 'Deleted',
);