<?php
// created: 2018-05-29 03:38:57
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Groups',
  'LBL_GROUP_NAME' => 'Group Name:',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_TEAM' => 'Team:',
  'LBL_LIST_TITLE' => 'Groups',
  'LNK_ALL_GROUPS' => 'All Groups',
  'LNK_NEW_GROUP' => 'Create Group',
  'LNK_CONVERT_USER' => 'Convert User to Group',
);