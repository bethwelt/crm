<?php
// created: 2018-05-29 03:38:57
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Roles',
  'LBL_MODULE_TITLE' => 'Roles: Home',
  'LBL_ROLE' => 'Role',
  'LBL_NAME' => 'Name',
  'LBL_DESCRIPTION' => 'Description',
  'LIST_ROLES' => 'List Roles',
  'LBL_USERS_SUBPANEL_TITLE' => 'Users',
  'LIST_ROLES_BY_USER' => 'List Roles By User',
  'LBL_LIST_FORM_TITLE' => 'Roles',
  'LBL_ROLES_SUBPANEL_TITLE' => 'User Roles',
  'LBL_SEARCH_FORM_TITLE' => 'Search',
  'LBL_CREATE_ROLE' => 'Create Role',
  'LBL_EDIT_VIEW_DIRECTIONS' => 'Double click on a cell to change value.',
  'LBL_ACCESS_DEFAULT' => 'Not Set',
  'LBL_ACTION_ADMIN' => 'Access Type',
  'LBL_ALL' => 'All',
  'LBL_DUPLICATE_OF' => 'Duplicate Of ',
  'LBL_SECURITYGROUPS' => 'Security Groups',
);